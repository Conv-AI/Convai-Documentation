

#include "ConvaiVisionBaseUtils.h"
#include "Engine/Texture2D.h"
#include "IImageWrapperModule.h"
#include "IImageWrapper.h"
#include "ImageUtils.h"
#include "Engine/TextureRenderTarget2D.h"
#include "RenderUtils.h"

DEFINE_LOG_CATEGORY(ConvaiVisionBaseUtilsLog);

bool UConvaiVisionBaseUtils::ConvertCompressedDataToTexture2D(const TArray<uint8>& CompressedData, UTexture2D*& Texture)
{
    // Cache the ImageWrapperModule to avoid loading it every time
    static IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
    EImageFormat DetectedFormat = ImageWrapperModule.DetectImageFormat(CompressedData.GetData(), CompressedData.Num());
    TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(DetectedFormat);

    if (ImageWrapper.IsValid() && ImageWrapper->SetCompressed(CompressedData.GetData(), CompressedData.Num()))
    {
        TArray<uint8> UncompressedBGRA;

        if (ImageWrapper->GetRaw(ERGBFormat::BGRA, 8, UncompressedBGRA))
        {
            const int32 Width = ImageWrapper->GetWidth();
            const int32 Height = ImageWrapper->GetHeight();

            if (!Texture)
            {
                Texture = UTexture2D::CreateTransient(Width, Height, PF_B8G8R8A8);
                if (!Texture)
                {
                    return false; 
                }
            }
            else if (Texture->GetSizeX() != Width || Texture->GetSizeY() != Height)
            {
                Texture = UTexture2D::CreateTransient(Width, Height, PF_B8G8R8A8);
                if (!Texture)
                {
                    return false; 
                }
            }

            void* TextureData = Texture->GetPlatformData()->Mips[0].BulkData.Lock(LOCK_READ_WRITE);
            const int32 TextureDataSize = UncompressedBGRA.Num();

            if (TextureDataSize == Texture->GetPlatformData()->Mips[0].BulkData.GetBulkDataSize())
            {
                FMemory::Memcpy(TextureData, UncompressedBGRA.GetData(), TextureDataSize);
            }
            else
            {
                Texture->GetPlatformData()->Mips[0].BulkData.Unlock();
                return false;
            }

            Texture->GetPlatformData()->Mips[0].BulkData.Unlock();
            Texture->UpdateResource();

            return true; 
        }
        return false;
    }
    return false; 
}

bool UConvaiVisionBaseUtils::ConvertRawDataToTexture2D(const TArray<uint8>& RawData, int32 Width, int32 Height, UTexture2D*& Texture)
{
    if (RawData.Num() != Width * Height * 4)
    {
        return false;
    }

    if (!Texture || Texture->GetSizeX() != Width || Texture->GetSizeY() != Height)
    {
        Texture = UTexture2D::CreateTransient(Width, Height, PF_B8G8R8A8);
        if (!Texture)
        {
            return false;
        }
    }

    void* TextureData = Texture->GetPlatformData()->Mips[0].BulkData.Lock(LOCK_READ_WRITE);

    FMemory::Memcpy(TextureData, RawData.GetData(), RawData.Num());

    Texture->GetPlatformData()->Mips[0].BulkData.Unlock();
    Texture->UpdateResource();

    return true;
}

bool UConvaiVisionBaseUtils::GetRawImageData(UTexture2D* CapturedImage, TArray<uint8>& OutData, int& width, int& height)
{
    if (!CapturedImage)
    {
        UE_LOG(LogTemp, Error, TEXT("No image captured"));
        return false;
    }

    // Get the first mip level (highest resolution) from the captured texture
    FTexture2DMipMap& Mip = CapturedImage->GetPlatformData()->Mips[0];
    width = Mip.SizeX;
    height = Mip.SizeY;

    // Lock the bulk data to access the raw pixel data
    void* RawData = Mip.BulkData.Lock(LOCK_READ_ONLY);

    const int32 NumPixels = width * height;

    // Check the pixel format and process accordingly
    if (CapturedImage->GetPlatformData()->PixelFormat == EPixelFormat::PF_B8G8R8A8 ||
        CapturedImage->GetPlatformData()->PixelFormat == EPixelFormat::PF_R8G8B8A8)
    {
        // Prepare output array, 3 bytes per pixel (RGB)
        OutData.SetNumUninitialized(NumPixels * 4);

        uint8* SrcPtr = static_cast<uint8*>(RawData); // Source pointer for raw texture data
        uint8* DstPtr = OutData.GetData();           // Destination pointer for RGB data

        FMemory::Memcpy(DstPtr, SrcPtr, OutData.Num());

    }
    else
    {
        // Unsupported pixel format, log error
        UE_LOG(LogTemp, Error, TEXT("Unsupported pixel format: %d"), static_cast<int32>(CapturedImage->GetPlatformData()->PixelFormat));
        Mip.BulkData.Unlock();
        return false;
    }

    // Unlock the bulk data after reading
    Mip.BulkData.Unlock();
    return true;
}

bool UConvaiVisionBaseUtils::TextureRenderTarget2DToBytes(UTextureRenderTarget2D* TextureRenderTarget2D, const EImageFormat ImageFormat, TArray<uint8>& ByteArray, const int32 CompressionQuality)
{
    ByteArray = TArray<uint8>();

    if (TextureRenderTarget2D == nullptr)
    {
        return false;
    }
    if (TextureRenderTarget2D->GetFormat() != PF_B8G8R8A8)
    {
        UE_LOG(LogBlueprintUserMessages, Error, TEXT("in ImageToBytes, the TextureRenderTarget2D has a [Render Target Format] that is not supported, use [RTF RGBA8] instead ([PF_B8G8R8A8] in C++)"));
        return false;
    }

    FRenderTarget* RenderTarget = TextureRenderTarget2D->GameThread_GetRenderTargetResource();
    if (RenderTarget == nullptr)
    {
        return false;
    }

    TArray<FColor> Pixels;
    if (!RenderTarget->ReadPixels(Pixels))
    {
        return false;
    }
    for (FColor& Pixel : Pixels)
    {
        Pixel.A = 255;
    }

    return PixelsToBytes(TextureRenderTarget2D->SizeX, TextureRenderTarget2D->SizeY, Pixels, ImageFormat, ByteArray, CompressionQuality);
}

bool UConvaiVisionBaseUtils::PixelsToBytes(const int32 Width, const int32 Height, const TArray<FColor>& Pixels, const EImageFormat ImageFormat, TArray<uint8>& ByteArray, const int32 CompressionQuality)
{
    ByteArray = TArray<uint8>();

    if ((Width <= 0) || (Height <= 0))
    {
        return false;
    }

    if ((CompressionQuality < 0) || (CompressionQuality > 100))
    {
        UE_LOG(LogBlueprintUserMessages, Error, TEXT("in PixelsToBytes, an invalid CompressionQuality (%i) has been given, should be 1-100 or 0 for the default value"), CompressionQuality);
        return false;
    }

    int32 Total = Width * Height;
    if (Total != Pixels.Num())
    {
        UE_LOG(LogBlueprintUserMessages, Error, TEXT("in PixelsToBytes, the number of given Pixels (%i) don't match the given Width (%i) x Height (%i) (Width x Height: %i)"), Pixels.Num(), Width, Height, Total);
        return false;
    }

    if (ImageFormat == EImageFormat::Invalid || ImageFormat == EImageFormat::BMP || ImageFormat == EImageFormat::ICO || ImageFormat == EImageFormat::ICNS)
    {
        UE_LOG(LogBlueprintUserMessages, Error, TEXT("in PixelsToBytes, unsupported or invalid compression format"));
        return false;
    }

    if (ImageFormat == EImageFormat::GrayscaleJPEG)
    {
        TArray<uint8> MutablePixels;
        for (int32 i = 0; i < Total; i++)
        {
            MutablePixels.Add(static_cast<uint8>(FMath::RoundToDouble((0.2125 * Pixels[i].R) + (0.7154 * Pixels[i].G) + (0.0721 * Pixels[i].B))));
        }

        IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
        TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(ImageFormat);
        if (!ImageWrapper.IsValid() || !ImageWrapper->SetRaw(MutablePixels.GetData(), MutablePixels.Num(), Width, Height, ERGBFormat::Gray, 8))
        {
            return false;
        }

        ByteArray = ImageWrapper->GetCompressed(CompressionQuality);
    }
    else
    {
        TArray<FColor> MutablePixels = Pixels;
        for (int32 i = 0; i < Total; i++)
        {
            MutablePixels[i].R = Pixels[i].B;
            MutablePixels[i].B = Pixels[i].R;
        }

        IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
        TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(ImageFormat);
        if (!ImageWrapper.IsValid() || !ImageWrapper->SetRaw(&MutablePixels[0], MutablePixels.Num() * sizeof(FColor), Width, Height, ERGBFormat::RGBA, 8))
        {
            return false;
        }

        ByteArray = ImageWrapper->GetCompressed(CompressionQuality);
    }

    return true;
}
