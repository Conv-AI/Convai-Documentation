// Fill out your copyright notice in the Description page of Project Settings.


#include "EnvironmentWebcame.h"
#include "Components/SceneCaptureComponent2D.h"
#include "ConvaiVisionBaseUtils.h"
#include "Engine/TextureRenderTarget2D.h"

UEnvironmentWebcame::UEnvironmentWebcame(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
    PrimaryComponentTick.bCanEverTick = true;

    CaptureComponent = CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("EnvironmentSceneCapture2D"));
    if (CaptureComponent)
    {
        CaptureComponent->SetupAttachment(this);
        CaptureComponent->bCaptureEveryFrame = false; 
        CaptureComponent->bCaptureOnMovement = false;
        CaptureComponent->CaptureSource = ESceneCaptureSource::SCS_FinalToneCurveHDR;
    }
}

void UEnvironmentWebcame::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (GetState() == EVisionState::Capturing && OnFrameReady.IsBound())
    {
        OnFrameReady.Broadcast();        
    } 
}


void UEnvironmentWebcame::Start()
{
    if (!CanStart())
        return;

    Super::Start();

    if (!CaptureComponent->TextureTarget)
    {
        CaptureComponent->TextureTarget = ConvaiRenderTarget;
    }

    CaptureComponent->bCaptureEveryFrame = true;

    OnFirstFrameCaptured.ExecuteIfBound();
}

void UEnvironmentWebcame::Stop()
{
    if (!CanStop())
        return;

    Super::Stop();
     
    if (CaptureComponent)
    {
        CaptureComponent->bCaptureEveryFrame = false;
        OnFramesStopped.ExecuteIfBound();
    }
}

bool UEnvironmentWebcame::CaptureCompressed(int& width, int& height, TArray<uint8>& data, float ForceCompressionRatio)
{
    width = ConvaiRenderTarget->SizeX;
    height = ConvaiRenderTarget->SizeY;
    return UConvaiVisionBaseUtils::TextureRenderTarget2DToBytes(ConvaiRenderTarget, EImageFormat::JPEG, data, ForceCompressionRatio);    
}

bool UEnvironmentWebcame::CaptureRaw(int& width, int& height, TArray<uint8>& data)
{
    width = ConvaiRenderTarget->SizeX;
    height = ConvaiRenderTarget->SizeY;
    return UConvaiVisionBaseUtils::TextureRenderTarget2DToBytes(ConvaiRenderTarget, EImageFormat::PNG, data);
}

UTexture* UEnvironmentWebcame::GetImageTexture(ETextureSourceType& TextureSourceType)
{
    TextureSourceType = ETextureSourceType::RenderTarget2D;
    return ConvaiRenderTarget;
}

bool UEnvironmentWebcame::CanStart()
{
    if (!Super::CanStart())
        return false;

    if (!CaptureComponent || !ConvaiRenderTarget)
    {
        if (!CaptureComponent)
        {
            SetErrorCodeAndMessage(-1, TEXT("CaptureComponent is null. Cannot start capture."));
        }
        else if (!ConvaiRenderTarget)
        {
            SetErrorCodeAndMessage(-1, TEXT("ConvaiRenderTarget is null. Cannot start capture."));
        }
        
        return false;
    }

    return true;
}